#!/usr/bin/env python3
"""Proper Irium wallet CLI with persistent storage."""

import sys
import json
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irium.wallet import Wallet, KeyPair

WALLET_FILE = "irium-wallet.json"

def load_wallet():
    """Load wallet from file or create new one."""
    if os.path.exists(WALLET_FILE):
        with open(WALLET_FILE, 'r') as f:
            data = json.load(f)
        wallet = Wallet()
        for addr, wif in data.get('keys', {}).items():
            wallet.import_wif(wif)
        return wallet, data
    return Wallet(), {'keys': {}, 'addresses': []}

def save_wallet(wallet, data):
    """Save wallet to file."""
    # Update keys from wallet
    data['keys'] = {}
    data['addresses'] = list(wallet.addresses())
    for addr in wallet.addresses():
        # Get the key from wallet (this is a simplified approach)
        # In a real implementation, you'd store the WIF when creating keys
        pass
    with open(WALLET_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def main():
    if len(sys.argv) < 2:
        print("Irium Wallet CLI - Proper Implementation")
        print("Usage:")
        print("  python3 irium-wallet-proper.py new-address")
        print("  python3 irium-wallet-proper.py import-wif <WIF>")
        print("  python3 irium-wallet-proper.py balance")
        print("  python3 irium-wallet-proper.py addresses")
        print("  python3 irium-wallet-proper.py generate-key")
        print("  python3 irium-wallet-proper.py create-wallet")
        print("  python3 irium-wallet-proper.py show-wallet")
        print("  python3 irium-wallet-proper.py show-keys")
        return

    command = sys.argv[1]
    
    if command == "new-address":
        wallet, data = load_wallet()
        key = KeyPair.generate()
        wif = key.to_wif()
        address = key.address()
        wallet.import_wif(wif)
        data['keys'][address] = wif
        save_wallet(wallet, data)
        print(f"New address: {address}")
        print(f"WIF: {wif}")
        print(f"Public Key: {key.public_key().hex()}")
        
    elif command == "import-wif":
        if len(sys.argv) < 3:
            print("Error: WIF required")
            return
        wif = sys.argv[2]
        try:
            wallet, data = load_wallet()
            address = wallet.import_wif(wif)
            data['keys'][address] = wif
            save_wallet(wallet, data)
            print(f"Imported address: {address}")
            print(f"WIF: {wif}")
            key = KeyPair.from_wif(wif)
            print(f"Public Key: {key.public_key().hex()}")
        except Exception as e:
            print(f"Error importing WIF: {e}")
            
    elif command == "balance":
        wallet, data = load_wallet()
        balance = wallet.balance()
        print(f"Balance: {balance} IRM")
        
    elif command == "addresses":
        wallet, data = load_wallet()
        addresses = list(wallet.addresses())
        print(f"Addresses: {addresses}")
        
    elif command == "generate-key":
        key = KeyPair.generate()
        wif = key.to_wif()
        address = key.address()
        print(f"Private Key (WIF): {wif}")
        print(f"Address: {address}")
        print(f"Public Key: {key.public_key().hex()}")
        
    elif command == "create-wallet":
        wallet, data = load_wallet()
        key = KeyPair.generate()
        wif = key.to_wif()
        address = key.address()
        wallet.import_wif(wif)
        data['keys'][address] = wif
        save_wallet(wallet, data)
        print(f"Wallet created!")
        print(f"Address: {address}")
        print(f"WIF: {wif}")
        print(f"Public Key: {key.public_key().hex()}")
        print("Save this WIF to backup your wallet!")
        
    elif command == "show-wallet":
        wallet, data = load_wallet()
        addresses = list(wallet.addresses())
        balance = wallet.balance()
        print(f"Wallet Status:")
        print(f"  Addresses: {len(addresses)}")
        print(f"  Balance: {balance} IRM")
        for addr in addresses:
            print(f"    {addr}")
            
    elif command == "show-keys":
        wallet, data = load_wallet()
        print(f"Wallet Keys:")
        for address, wif in data.get('keys', {}).items():
            key = KeyPair.from_wif(wif)
            print(f"  Address: {address}")
            print(f"  WIF: {wif}")
            print(f"  Public Key: {key.public_key().hex()}")
            print()
        
    else:
        print(f"Unknown command: {command}")

if __name__ == "__main__":
    main()
