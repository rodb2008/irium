# This patch adds automatic block rescanning to irium-node.py

import sys

# Read the current file
with open('scripts/irium-node.py', 'r') as f:
    content = f.read()

# Find the run() method and add periodic rescanning
# We'll add it after the P2P node starts

patch = '''
        # Periodic block rescan (every 30 seconds)
        async def rescan_blocks():
            """Periodically rescan blocks directory for new blocks."""
            while True:
                await asyncio.sleep(30)  # Check every 30 seconds
                
                blocks_dir = os.path.expanduser("~/.irium/blocks")
                if os.path.exists(blocks_dir):
                    block_files = sorted([f for f in os.listdir(blocks_dir) if f.endswith(".json")])
                    if block_files:
                        max_height = 0
                        for block_file in block_files:
                            try:
                                with open(os.path.join(blocks_dir, block_file)) as bf:
                                    block_data = json.load(bf)
                                    if block_data["height"] > max_height:
                                        max_height = block_data["height"]
                            except:
                                pass
                        
                        if max_height > self.chain_state.height:
                            old_height = self.chain_state.height
                            self.chain_state.height = max_height
                            self.p2p.chain_height = max_height
                            print(f"📊 Detected new blocks! Updated height: {old_height} -> {max_height}")
        
        # Start rescan task
        asyncio.create_task(rescan_blocks())
'''

# Find where to insert (after p2p.start())
insert_point = content.find('await self.p2p.start()')
if insert_point == -1:
    print("❌ Could not find insertion point")
    sys.exit(1)

# Find the end of that line
end_of_line = content.find('\n', insert_point)

# Insert the patch
new_content = content[:end_of_line+1] + patch + content[end_of_line+1:]

# Write back
with open('scripts/irium-node.py', 'w') as f:
    f.write(new_content)

print("✅ Patch applied!")
