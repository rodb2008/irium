"""P2P networking for Irium blockchain."""

from __future__ import annotations
import asyncio
import time
import random
from typing import Dict, Set, Optional, Callable
from dataclasses import dataclass, field

from .protocol import (
    Message, MessageType,
    HandshakeMessage, PingMessage, PongMessage,
    GetPeersMessage, PeersMessage,
    BlockMessage, TxMessage, DisconnectMessage
)
from .network import PeerDirectory, SeedlistManager


@dataclass
class Peer:
    """Connected peer."""
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    address: str
    agent: str = "unknown"
    height: int = 0
    connected_at: float = field(default_factory=time.time)
    last_ping: float = field(default_factory=time.time)
    
    async def send_message(self, msg: Message) -> None:
        """Send a message to this peer."""
        try:
            data = msg.serialize()
            self.writer.write(data)
            await self.writer.drain()
        except Exception as e:
            print(f"Error sending message to {self.address}: {e}")
            raise
    
    async def recv_message(self) -> Optional[Message]:
        """Receive a message from this peer."""
        try:
            # Read header (6 bytes)
            header = await self.reader.readexactly(6)
            if not header:
                return None
            
            # Read payload
            msg = Message.deserialize(header)
            if msg.payload:
                # Already read in deserialize
                pass
            
            # Actually we need to read the payload separately
            # Let's fix the deserialization
            import struct
            version, msg_type, length = struct.unpack('!BBI', header)
            
            if length > 0:
                payload = await self.reader.readexactly(length)
            else:
                payload = b''
            
            return Message(msg_type=MessageType(msg_type), payload=payload)
            
        except asyncio.IncompleteReadError:
            return None
        except Exception as e:
            print(f"Error receiving message from {self.address}: {e}")
            return None
    
    def close(self) -> None:
        """Close connection."""
        try:
            self.writer.close()
        except:
            pass


class P2PNode:
    """P2P network node for Irium."""
    
    def __init__(
        self,
        port: int = 38291,
        max_peers: int = 8,
        agent: str = "irium-node/1.0",
        chain_height: int = 0
    ):
        self.port = port
        self.max_peers = max_peers
        self.agent = agent
        self.chain_height = chain_height
        
        self.peers: Dict[str, Peer] = {}
        self.server: Optional[asyncio.Server] = None
        self.running = False
        
        # Callbacks for handling messages
        self.on_block: Optional[Callable] = None
        self.on_tx: Optional[Callable] = None
        self.on_peer_connected: Optional[Callable] = None
        
        # Peer management
        self.peer_directory = PeerDirectory()
        self.seedlist_manager = SeedlistManager()
    
    async def start(self) -> None:
        """Start the P2P node."""
        print(f"🚀 Starting P2P Node on port {self.port}")
        self.running = True
        
        # Start server
        self.server = await asyncio.start_server(
            self._handle_incoming_connection,
            '0.0.0.0',
            self.port
        )
        
        print(f"✅ P2P Node listening on port {self.port}")
        
        # Start background tasks
        asyncio.create_task(self._connect_to_peers())
        asyncio.create_task(self._ping_peers())
        asyncio.create_task(self._cleanup_dead_peers())
    
    async def stop(self) -> None:
        """Stop the P2P node."""
        print("🛑 Stopping P2P Node...")
        self.running = False
        
        # Close all peer connections
        for peer in list(self.peers.values()):
            await self._disconnect_peer(peer, "Node shutting down")
        
        # Close server
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        print("✅ P2P Node stopped")
    
    async def _handle_incoming_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter
    ) -> None:
        """Handle incoming peer connection."""
        addr = writer.get_extra_info('peername')
        address = f"{addr[0]}:{addr[1]}"
        
        print(f"📥 Incoming connection from {address}")
        
        if len(self.peers) >= self.max_peers:
            print(f"⚠️  Max peers reached, rejecting {address}")
            writer.close()
            await writer.wait_closed()
            return
        
        peer = Peer(reader=reader, writer=writer, address=address)
        
        try:
            # Perform handshake
            if await self._perform_handshake(peer, is_initiator=False):
                self.peers[address] = peer
                print(f"✅ Peer connected: {address} ({peer.agent}, height: {peer.height})")
                
                if self.on_peer_connected:
                    await self.on_peer_connected(peer)
                
                # Handle messages from this peer
                await self._handle_peer_messages(peer)
            else:
                print(f"❌ Handshake failed with {address}")
                peer.close()
        
        except Exception as e:
            print(f"❌ Error handling connection from {address}: {e}")
            if address in self.peers:
                del self.peers[address]
            peer.close()
    
    async def _perform_handshake(self, peer: Peer, is_initiator: bool) -> bool:
        """Perform handshake with peer."""
        try:
            if is_initiator:
                # Send our handshake first
                handshake = HandshakeMessage(
                    version=1,
                    agent=self.agent,
                    height=self.chain_height,
                    timestamp=int(time.time())
                )
                await peer.send_message(handshake.to_message())
            
            # Receive their handshake
            msg = await asyncio.wait_for(peer.recv_message(), timeout=10.0)
            if not msg or msg.msg_type != MessageType.HANDSHAKE:
                return False
            
            their_handshake = HandshakeMessage.from_message(msg)
            peer.agent = their_handshake.agent
            peer.height = their_handshake.height
            
            if not is_initiator:
                # Send our handshake in response
                handshake = HandshakeMessage(
                    version=1,
                    agent=self.agent,
                    height=self.chain_height,
                    timestamp=int(time.time())
                )
                await peer.send_message(handshake.to_message())
            
            # Register peer
            multiaddr = f"/ip4/{peer.address.split(':')[0]}/tcp/{self.port}"
            self.peer_directory.register_connection(multiaddr, peer.agent)
            
            return True
        
        except asyncio.TimeoutError:
            print(f"⚠️  Handshake timeout with {peer.address}")
            return False
        except Exception as e:
            print(f"⚠️  Handshake error with {peer.address}: {e}")
            return False
    
    async def _handle_peer_messages(self, peer: Peer) -> None:
        """Handle messages from a connected peer."""
        while self.running and peer.address in self.peers:
            try:
                msg = await peer.recv_message()
                if not msg:
                    break
                
                # Handle different message types
                if msg.msg_type == MessageType.PING:
                    await self._handle_ping(peer, msg)
                elif msg.msg_type == MessageType.PONG:
                    await self._handle_pong(peer, msg)
                elif msg.msg_type == MessageType.GET_PEERS:
                    await self._handle_get_peers(peer)
                elif msg.msg_type == MessageType.PEERS:
                    await self._handle_peers(peer, msg)
                elif msg.msg_type == MessageType.BLOCK:
                    await self._handle_block(peer, msg)
                elif msg.msg_type == MessageType.TX:
                    await self._handle_tx(peer, msg)
                elif msg.msg_type == MessageType.DISCONNECT:
                    break
            
            except Exception as e:
                print(f"❌ Error handling message from {peer.address}: {e}")
                break
        
        # Clean up
        await self._disconnect_peer(peer, "Connection closed")
    
    async def _handle_ping(self, peer: Peer, msg: Message) -> None:
        """Handle ping message."""
        ping = PingMessage.from_message(msg)
        pong = PongMessage(nonce=ping.nonce)
        await peer.send_message(pong.to_message())
    
    async def _handle_pong(self, peer: Peer, msg: Message) -> None:
        """Handle pong message."""
        peer.last_ping = time.time()
    
    async def _handle_get_peers(self, peer: Peer) -> None:
        """Handle get peers request."""
        # Send list of known peers
        peer_list = [p.address for p in self.peers.values() if p.address != peer.address]
        peers_msg = PeersMessage(peers=peer_list[:50])  # Limit to 50
        await peer.send_message(peers_msg.to_message())
    
    async def _handle_peers(self, peer: Peer, msg: Message) -> None:
        """Handle peers message."""
        peers_msg = PeersMessage.from_message(msg)
        print(f"📋 Received {len(peers_msg.peers)} peers from {peer.address}")
        # Could connect to these peers
    
    async def _handle_block(self, peer: Peer, msg: Message) -> None:
        """Handle block message."""
        if self.on_block:
            block_msg = BlockMessage.from_message(msg)
            await self.on_block(peer, block_msg.block_data)
    
    async def _handle_tx(self, peer: Peer, msg: Message) -> None:
        """Handle transaction message."""
        if self.on_tx:
            tx_msg = TxMessage.from_message(msg)
            await self.on_tx(peer, tx_msg.tx_data)
    
    async def _connect_to_peers(self) -> None:
        """Background task to connect to peers from seedlist."""
        while self.running:
            try:
                if len(self.peers) < self.max_peers:
                    # Get seedlist
                    seedlist = list(self.seedlist_manager.merged_seedlist())
                    if seedlist:
                        # Try random peer
                        multiaddr = random.choice(seedlist)
                        await self._connect_to_peer(multiaddr)
                
                await asyncio.sleep(30)  # Try every 30 seconds
            
            except Exception as e:
                print(f"❌ Error in peer connection task: {e}")
                await asyncio.sleep(30)
    
    async def _connect_to_peer(self, multiaddr: str) -> None:
        """Connect to a peer."""
        try:
            # Parse multiaddr (simplified)
            # Format: /ip4/1.2.3.4/tcp/38291
            parts = multiaddr.strip('/').split('/')
            if len(parts) >= 4 and parts[0] == 'ip4' and parts[2] == 'tcp':
                host = parts[1]
                port = int(parts[3])
                
                address = f"{host}:{port}"
                
                if address in self.peers:
                    return  # Already connected

                # Skip connecting to self
                if host in ["127.0.0.1", "localhost"] or port == self.port:
                    return

                    return  # Already connected
                
                print(f"📤 Connecting to {address}...")
                
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, port),
                    timeout=10.0
                )
                
                peer = Peer(reader=reader, writer=writer, address=address)
                
                if await self._perform_handshake(peer, is_initiator=True):
                    self.peers[address] = peer
                    print(f"✅ Connected to peer: {address} ({peer.agent})")
                    
                    if self.on_peer_connected:
                        await self.on_peer_connected(peer)
                    
                    # Handle messages from this peer
                    asyncio.create_task(self._handle_peer_messages(peer))
                else:
                    peer.close()
        
        except asyncio.TimeoutError:
            print(f"⚠️  Connection timeout: {multiaddr}")
        except Exception as e:
            print(f"❌ Failed to connect to {multiaddr}: {e}")
    
    async def _ping_peers(self) -> None:
        """Background task to ping peers."""
        while self.running:
            try:
                for peer in list(self.peers.values()):
                    nonce = random.randint(0, 2**64 - 1)
                    ping = PingMessage(nonce=nonce)
                    await peer.send_message(ping.to_message())
                
                await asyncio.sleep(60)  # Ping every 60 seconds
            
            except Exception as e:
                print(f"❌ Error in ping task: {e}")
                await asyncio.sleep(60)
    
    async def _cleanup_dead_peers(self) -> None:
        """Background task to remove dead peers."""
        while self.running:
            try:
                now = time.time()
                for address, peer in list(self.peers.items()):
                    # Remove peer if no pong in 3 minutes
                    if now - peer.last_ping > 180:
                        print(f"⚠️  Peer {address} timed out")
                        await self._disconnect_peer(peer, "Timeout")
                
                await asyncio.sleep(30)  # Check every 30 seconds
            
            except Exception as e:
                print(f"❌ Error in cleanup task: {e}")
                await asyncio.sleep(30)
    
    async def _disconnect_peer(self, peer: Peer, reason: str) -> None:
        """Disconnect a peer."""
        try:
            # Send disconnect message
            disconnect = DisconnectMessage(reason=reason)
            await peer.send_message(disconnect.to_message())
        except:
            pass
        
        # Remove from peers
        if peer.address in self.peers:
            del self.peers[peer.address]
            print(f"👋 Disconnected from {peer.address}: {reason}")
        
        peer.close()
    
    async def broadcast_block(self, block_data: bytes) -> None:
        """Broadcast a block to all peers."""
        block_msg = BlockMessage(block_data=block_data)
        msg = block_msg.to_message()
        
        for peer in list(self.peers.values()):
            try:
                await peer.send_message(msg)
            except Exception as e:
                print(f"❌ Failed to broadcast block to {peer.address}: {e}")
    
    async def broadcast_tx(self, tx_data: bytes) -> None:
        """Broadcast a transaction to all peers."""
        tx_msg = TxMessage(tx_data=tx_data)
        msg = tx_msg.to_message()
        
        for peer in list(self.peers.values()):
            try:
                await peer.send_message(msg)
            except Exception as e:
                print(f"❌ Failed to broadcast tx to {peer.address}: {e}")
    
    def get_peer_count(self) -> int:
        """Get number of connected peers."""
        return len(self.peers)
    
    def get_peers_info(self) -> list:
        """Get information about connected peers."""
        return [
            {
                'address': peer.address,
                'agent': peer.agent,
                'height': peer.height,
                'connected': int(time.time() - peer.connected_at)
            }
            for peer in self.peers.values()
        ]
