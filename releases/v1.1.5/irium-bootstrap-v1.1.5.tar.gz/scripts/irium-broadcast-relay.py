#!/usr/bin/env python3
"""
Irium Broadcast Relay - Monitors for new blocks and broadcasts to P2P network
"""
import asyncio
import os
import json
import time
from irium.p2p import P2PNode

BLOCKS_DIR = os.path.expanduser("~/.irium/blocks")
BROADCAST_MARKER = os.path.expanduser("~/.irium/last_broadcast_height")

class BroadcastRelay:
    def __init__(self):
        self.p2p = P2PNode(
            port=38291,
            max_peers=8,
            agent="irium-relay/1.0",
            chain_height=0
        )
        self.last_height = self.load_last_broadcast()
    
    def load_last_broadcast(self):
        """Load the last broadcasted block height."""
        if os.path.exists(BROADCAST_MARKER):
            with open(BROADCAST_MARKER) as f:
                return int(f.read().strip())
        return 0
    
    def save_last_broadcast(self, height):
        """Save the last broadcasted height."""
        with open(BROADCAST_MARKER, 'w') as f:
            f.write(str(height))
    
    async def monitor_and_broadcast(self):
        """Monitor blocks directory and broadcast new blocks."""
        print("🔄 Starting broadcast relay...")
        print(f"📡 Last broadcast: block {self.last_height}")
        
        while True:
            try:
                # Scan for new blocks
                if os.path.exists(BLOCKS_DIR):
                    block_files = sorted([f for f in os.listdir(BLOCKS_DIR) if f.startswith("block_") and f.endswith(".json")])
                    
                    for block_file in block_files:
                        # Extract height
                        try:
                            height = int(block_file.replace("block_", "").replace(".json", ""))
                        except:
                            continue
                        
                        # If this is a new block we haven't broadcast
                        if height > self.last_height:
                            block_path = os.path.join(BLOCKS_DIR, block_file)
                            
                            # Read block data
                            with open(block_path, 'rb') as f:
                                block_data = f.read()
                            
                            # Broadcast to network
                            peer_count = len(self.p2p.peers)
                            print(f"📡 Broadcasting block {height} to {peer_count} peers...")
                            
                            if hasattr(self.p2p, 'broadcast_block'):
                                await self.p2p.broadcast_block(block_data)
                            
                            # Update marker
                            self.last_height = height
                            self.save_last_broadcast(height)
                            print(f"✅ Block {height} broadcast complete!")
                
                # Check every 5 seconds
                await asyncio.sleep(5)
                
            except Exception as e:
                print(f"⚠️  Broadcast error: {e}")
                await asyncio.sleep(5)
    
    async def start(self):
        """Start the relay."""
        await self.p2p.start()
        await self.monitor_and_broadcast()

async def main():
    relay = BroadcastRelay()
    await relay.start()

if __name__ == "__main__":
    asyncio.run(main())
