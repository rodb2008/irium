#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="${REPO_DIR:-$HOME/irium}"
BOOT_DIR="${BOOT_DIR:-$REPO_DIR/bootstrap}"
CONFIG_DIR="${CONFIG_DIR:-$REPO_DIR/configs}"
BIN="${BIN:-$REPO_DIR/target/release/iriumd}"
SEED="$BOOT_DIR/seedlist.txt"
ANCH="$BOOT_DIR/anchors.json"

log(){ printf '[%s] %s\n' "$(date +'%F %T')" "$*" >&2; }

log "Bootstrap files:"
log "  Seedlist: $SEED"
log "  Anchors: $ANCH"

export IRIUM_SEEDLIST="$SEED"
export IRIUM_ANCHORS="$ANCH"

log "Starting Irium daemon..."
exec "$BIN" start --config-dir "$REPO_DIR/configs" -v
